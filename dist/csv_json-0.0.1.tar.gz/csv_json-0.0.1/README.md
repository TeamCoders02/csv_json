# csv_json
This repository is made to convert csv files to json files and vice-versa.