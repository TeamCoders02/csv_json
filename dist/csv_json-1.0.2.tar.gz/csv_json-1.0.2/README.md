# About

A python package to convert the CSV (Comma Separated values) format files to the JSON (JavaScript
Object Notation) files and vice versa i.e. JSON files to CSV.

